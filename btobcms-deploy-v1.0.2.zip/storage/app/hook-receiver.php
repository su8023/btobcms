<?php

/**
 * 本地 Webhook 接收器：验证飞书插件推送链路用。
 * 运行：php -S 127.0.0.1:9911 storage/app/hook-receiver.php
 */

declare(strict_types=1);

$logFile = __DIR__.'/hook-log.jsonl';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $body = file_get_contents('php://input');
    file_put_contents($logFile, date('c')."\t".($body ?: '')."\n", FILE_APPEND);
    header('Content-Type: application/json');
    echo json_encode(['code' => 0, 'msg' => 'success']);

    return;
}

http_response_code(200);
header('Content-Type: text/plain');
echo 'hook receiver ready';
