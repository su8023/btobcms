<?php echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>

<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
@foreach($sections as $section)
    <sitemap>
        <loc>{{ htmlspecialchars($section, ENT_XML1) }}</loc>
    </sitemap>
@endforeach
</sitemapindex>
