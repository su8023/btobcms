<?php

return [
    'name' => 'AiContentWriter',
];
