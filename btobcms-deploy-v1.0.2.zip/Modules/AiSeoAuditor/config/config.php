<?php

return [
    'name' => 'AiSeoAuditor',
];
