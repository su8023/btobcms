<?php

/**
 * 生成宝塔网页上传部署包（一次性脚本）：
 * 排除 .git/.env/本地数据库/运行时产物，包含 vendor（服务器免 composer）。
 * 产物：btobcms-deploy-v1.0.2.zip
 */

chdir(__DIR__);
$zipFile = 'btobcms-deploy-v1.0.2.zip';
@unlink($zipFile);

$zip = new ZipArchive();
$zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE);

$excludeDirs = ['.git', 'node_modules', '.idea', '.vscode'];
$excludeFiles = [
    '.env',
    'database/database.sqlite',
    'public/storage',                 // 开发机软链
    'storage/app/installed.lock',
    'storage/app/update-center.log',
    '_release.json',
];

$keepEmptyDirs = [
    'storage/framework/cache/data',
    'storage/framework/sessions',
    'storage/framework/views',
    'storage/logs',
    'storage/app/public',
    'bootstrap/cache',
];

$count = 0;
$it = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator('.', FilesystemIterator::SKIP_DOTS),
    RecursiveIteratorIterator::LEAVES_ONLY,
);

foreach ($it as $file) {
    $path = str_replace('\\', '/', $file->getPathname());
    $rel = mb_substr($path, 2); // 去掉 ./

    // 排除目录
    foreach ($excludeDirs as $d) {
        if (str_starts_with($rel, $d.'/')) {
            continue 2;
        }
    }
    // 排除文件
    if (in_array($rel, $excludeFiles, true)) {
        continue;
    }
    // 排除运行时产物
    if (preg_match('#^storage/app/(install-browser\.sqlite|install-test\.sqlite|backups/|seo-audits/)#', $rel)) {
        continue;
    }
    if (preg_match('#^storage/(logs|framework/cache|framework/sessions|framework/views)/.#', $rel)) {
        continue; // 内容排除，目录用空占位保留
    }
    if (preg_match('#^bootstrap/cache/.+\.php$#', $rel)) {
        continue;
    }

    $zip->addFile($path, $rel);
    $count++;
}

// 保证 Laravel 必需的空目录存在（解压后结构完整）
foreach ($keepEmptyDirs as $dir) {
    $zip->addEmptyDir($dir);
}

$zip->close();
$size = filesize($zipFile);
echo "打包完成：{$zipFile}\n";
echo "文件数：{$count}，压缩包大小：".round($size / 1048576, 1)." MB\n";
